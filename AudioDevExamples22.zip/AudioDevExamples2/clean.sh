rm -rf CMakeFiles/ CMakeCache.txt ./Standalone/LoadingSVG/LoadingSVG_artefacts/Release
#cmake . && make 
